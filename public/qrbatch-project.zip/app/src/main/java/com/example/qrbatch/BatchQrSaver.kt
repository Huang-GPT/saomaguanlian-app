package com.example.qrbatch

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.util.Log
import java.io.File

/**
 * 批量生成二维码并保存到设备存储。
 * 返回保存成功的文件路径列表；失败时返回空列表并记录日志。
 */
object BatchQrSaver {

    private const val TAG = "BatchQrSaver"
    private const val FOLDER = "QRBatch"
    private const val QR_SIZE = 512

    /**
     * 保存到应用私有目录（无需运行时权限）。
     * 目录: <filesDir>/QRBatch/QR_1.png ...
     */
    fun saveAll(context: Context, items: List<String>): List<File> {
        val dir = File(context.filesDir, FOLDER)
        if (!dir.exists() && !dir.mkdirs()) {
            Log.e(TAG, "无法创建目录 ${dir.absolutePath}")
            return emptyList()
        }
        val bitmaps = QrBitmapFactory.generateBatch(items, QR_SIZE)
        if (bitmaps.size != items.size) {
            Log.w(TAG, "部分二维码生成失败：期望 ${items.size}，实际 ${bitmaps.size}")
        }
        val results = mutableListOf<File>()
        items.forEachIndexed { index, _ ->
            val file = File(dir, "QR_${index + 1}.png")
            try {
                if (index < bitmaps.size) {
                    file.outputStream().use { out ->
                        bitmaps[index].compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    results.add(file)
                } else {
                    Log.e(TAG, "第 ${index + 1} 个二维码生成失败，跳过")
                }
            } catch (e: Exception) {
                Log.e(TAG, "保存第 ${index + 1} 张失败", e)
            }
        }
        return results
    }

    /**
     * 保存到公共目录（Android Q+ 使用 MediaStore，低于 Q 需要 WRITE 权限）。
     * 简化实现：使用 getExternalFilesDir 公共可见目录。
     */
    fun sharedDir(context: Context): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            ?: File(context.filesDir, FOLDER)
        val f = File(dir, FOLDER)
        if (!f.exists()) f.mkdirs()
        return f
    }

    fun hasCameraPermission(activity: Activity): Boolean {
        return if (Build.VERSION.SDK_INT >= 23) {
            activity.checkSelfPermission(Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun requestCameraPermission(activity: Activity, code: Int,
                                 onGranted: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 23 &&
            activity.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            activity.requestPermissions(arrayOf(Manifest.permission.CAMERA), code)
        } else {
            onGranted()
        }
    }
}
