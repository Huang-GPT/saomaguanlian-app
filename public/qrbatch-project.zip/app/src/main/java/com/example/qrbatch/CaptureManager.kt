package com.example.qrbatch

import android.content.Intent
import com.google.zxing.integration.android.IntentIntegrator

/**
 * 摄像头扫码管理器（基于 ZXing-Android-Embedded）。
 * 封装 IntentIntegrator，扫码启动/结果解析。
 */
class CaptureManager(private val activity: android.app.Activity) {

    fun startScan(
        requestCode: Int,
        prompt: String = "将二维码/条形码对准取景框"
    ) {
        val integrator = IntentIntegrator(activity)
        integrator.setOrientationLocked(true)
        integrator.setPrompt(prompt)
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
        integrator.setRequestCode(requestCode)
        integrator.initiateScan()
    }

    fun handleResult(requestCode: Int, resultCode: Int, intent: Intent?): String? {
        return IntentIntegrator.parseActivityResult(requestCode, resultCode, intent)?.contents
    }
}