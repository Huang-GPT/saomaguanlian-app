package com.example.qrbatch

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQUEST_CAMERA = 100
        private const val REQUEST_SCAN = 101
    }

    private lateinit var btnScan: Button
    private lateinit var btnAdd: Button
    private lateinit var btnGenerate: Button
    private lateinit var etInput: EditText
    private lateinit var listView: ListView
    private lateinit var progress: ProgressBar
    private val items = mutableListOf<String>()
    private var results = mutableListOf<java.io.File>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var captureManager: CaptureManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnScan = findViewById(R.id.btn_scan)
        btnAdd = findViewById(R.id.btn_add)
        btnGenerate = findViewById(R.id.btn_generate)
        etInput = findViewById(R.id.et_input)
        listView = findViewById(R.id.lv_items)
        progress = findViewById(R.id.progress)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        captureManager = CaptureManager(this)

        btnScan.setOnClickListener {
            BatchQrSaver.requestCameraPermission(this, REQUEST_CAMERA) {
                captureManager.startScan(REQUEST_SCAN)
            }
        }
        btnAdd.setOnClickListener {
            val text = etInput.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "请输入内容", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            items.add(text)
            adapter.notifyDataSetChanged()
            etInput.text.clear()
        }
        btnGenerate.setOnClickListener {
            if (items.isEmpty()) {
                Toast.makeText(this, "列表为空，请先扫码或输入内容", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            progress.visibility = View.VISIBLE
            btnGenerate.isEnabled = false
            results = BatchQrSaver.saveAll(this, items).toMutableList()
            progress.visibility = View.GONE
            btnGenerate.isEnabled = true
            if (results.isNotEmpty()) {
                Toast.makeText(
                    this,
                    "已生成 ${results.size} 张二维码，保存至 ${results[0].parentFile.absolutePath}",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(this, "生成失败，请查看日志", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            captureManager.startScan(REQUEST_SCAN)
        } else {
            Toast.makeText(this, "需要相机权限才能扫码", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SCAN && resultCode == RESULT_OK) {
            val text = captureManager.handleResult(requestCode, resultCode, data)
            if (!text.isNullOrBlank()) {
                items.add(text)
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "已扫码并加入列表：$text", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
