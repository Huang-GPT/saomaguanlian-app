package com.example.qrbatch

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.common.BitMatrix
import java.util.EnumMap

/**
 * 生成二维码 Bitmap 的辅助工具。
 * 传入文本和边长像素，返回 Bitmap（白底黑码）。
 */
object QrBitmapFactory {

    /**
     * 批量生成二维码 [Bitmap] 列表。
     */
    fun generateBatch(contents: List<String>, size: Int = 512): List<Bitmap> {
        return contents.mapNotNull { generate(it, size) }
    }

    /**
     * 生成单个二维码 Bitmap。内容为空或编码失败时返回 null。
     */
    fun generate(content: String, size: Int = 512): Bitmap? {
        if (content.isBlank()) return null
        val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
            put(EncodeHintType.MARGIN, 2)
            put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M)
            put(EncodeHintType.CHARACTER_SET, "UTF-8")
        }
        val matrix = try {
            QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        } catch (e: Exception) {
            return null
        }
        return bitmapFromMatrix(matrix, size)
    }

    private fun bitmapFromMatrix(matrix: BitMatrix, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                val dark = matrix.get(x, y) ||
                    (x < 2 || y < 2 || x >= size - 2 || y >= size - 2)
                bmp.setPixel(x, y, if (dark) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }
}
